# Splunk-ES Role
## NOTICE - This role needs to be updated to pull required packages from Nexus and not the /var/share directory on the ansible server.

## Description
Installs and configures Splunk Enterprise Security (ES) on a Splunk server. The role deploys ES apps, configures data models, sets up saved searches, and implements forwarding scripts for security monitoring and incident response capabilities in the cyber range environment.

## Variable Definition Location
Variables for this role are defined in:
- **host_vars/[hostname].yml** for Splunk server configuration
- **group_vars/all.yml** for installer paths and admin credentials

## Required Variables

### In host_vars/[hostname].yml

| Variable | Required | Description |
|----------|----------|-------------|
| splunk_admin | Yes | Splunk admin username |
| splunk_admin_password | Yes | Splunk admin password |

### In group_vars/all.yml

| Variable | Required | Description |
|----------|----------|-------------|
| ansible_installers | Yes | Base path for installer files |
| staging_dir_linux | Yes | Linux staging directory for temporary files |

## Optional Variables

None - this role uses the required variables and expects specific file paths.

## Complete Example Configuration

### host_vars/site-splunk.yml
```yaml
ansible_host: 10.10.2.20
hostname: "site-splunk"
splunk_admin: "admin"
splunk_admin_password: "simspace1"
```
group_vars/all.yml
```yaml
ansible_installers: "/var/share/installers"
staging_dir_linux: "/var/tmp"
```
Files Required
The role expects the following files to be present:

{{ ansible_installers }}/splunk/apps/*.tgz - Splunk app packages
{{ ansible_installers }}/splunk/splunk-es.spl - Enterprise Security package
/etc/ansible/templates/splunkapps/ - Configuration templates:

cu-savedsearches.conf.j2
ep-savedsearches.conf.j2
cim-macros.conf.j2
cim-datamodels.conf.j2
es-savedsearches.conf.j2
stack_op_forwarder.py.j2
alert-savedsearches.conf.j2
